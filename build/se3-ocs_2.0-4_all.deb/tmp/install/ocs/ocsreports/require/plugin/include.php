<?php

require_once 'ComputerPlugin.php';
require_once 'XMLPluginsSerializer.php';

?>