<h3><?php echo  $l->g(1296);?></h3>
<?php
	iframe("http://ocsinventory-ng.factorfx.com");