<?php
// Configuracion de la autenticacion CAS

$cas_host="put here your server cas";
$cas_port=443;
$cas_uri="/cas";

?>