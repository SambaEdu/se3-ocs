$(function(){
	$(".dropdown-submenu-toggle").click(function (){
		window.location = this.href;
	});
});