<h3><?php echo  $l->g(1375);?></h3>
<?php
	iframe("//forums.ocsinventory-ng.org");
